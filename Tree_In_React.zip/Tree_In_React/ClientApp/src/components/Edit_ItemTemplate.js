﻿import React, { Component } from 'react';

class Edit_ItemTemplate extends Component {

    render()
    {
        return (
            <div>Display Edit_Item Template </div>
            );
    }
}

export default Edit_ItemTemplate;
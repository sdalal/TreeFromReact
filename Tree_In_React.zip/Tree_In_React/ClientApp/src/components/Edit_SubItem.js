﻿import React, { Component } from 'react';

class Edit_SubItem extends Component {

    render() {
        return (
            <div>Display Edit SubItem </div>
        );
    }
}

export default Edit_SubItem;
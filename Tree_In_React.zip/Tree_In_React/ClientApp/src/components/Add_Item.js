﻿import React, { Component } from 'react';

class Add_Item extends Component {

    render() {
        return (
            <div>Display Add Item </div>
        );
    }
}

export default Add_Item;
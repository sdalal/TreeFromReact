import React, { Component } from 'react';
import ProductsTree from './components/ProductsTreeView';

class App extends Component {
 
    
    render() {
        return (
            <div>
                <div className="TreeContainer">
                <table WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
                    <tr STYLE="BACKGROUND-COLOR: #5389bc">
                        <td HEIGHT="20" WIDTH="20%" align="left" NOWRAP>
                            <p>Items</p>
                        </td>

                        <td>
                            <a href onClick ="expandAll()">Expand</a>
                        </td>
                        <td>
                            <a href onClick="Minimize()">Minimize</a>
                        </td>

                    </tr>
                </table>
    
              
                    <br />
                    <ProductsTree />
                </div>
               
                <div className="BodyContainer">
                  
                  <p>Data needs to display here </p><br />
                          <p>Click on Tree node from the left open a component in this section   </p>
                </div>
        

            </div>
        );
    }
}


export default App;

